import { Shield, Brain, Lock, Code } from "lucide-react";
import { Card } from "@/components/ui/card";

const About = () => {
  const skills = [
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Advanced threat detection, penetration testing, and security architecture",
    },
    {
      icon: Brain,
      title: "Artificial Intelligence",
      description: "Machine learning, neural networks, and AI-powered security solutions",
    },
    {
      icon: Lock,
      title: "Encryption",
      description: "End-to-end encryption, cryptography, and secure data transmission",
    },
    {
      icon: Code,
      title: "Development",
      description: "Secure coding practices, DevSecOps, and security automation",
    },
  ];

  return (
    <section id="about" className="min-h-screen py-20 px-4 relative">
      <div className="absolute inset-0 grid-pattern opacity-10" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 text-glow">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-cyan to-neon-magenta mx-auto mb-8" />
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Passionate about securing digital ecosystems and leveraging AI to predict and prevent cyber threats. 
            With expertise spanning multiple domains, I create robust security solutions for the modern age.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            return (
              <Card 
                key={index}
                className="group p-8 bg-card/50 backdrop-blur-sm border-primary/20 hover:border-primary/50 transition-all duration-300 hover:scale-105 cursor-pointer relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/5 to-neon-magenta/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <div className="relative z-10">
                  <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-neon-cyan/20 to-neon-blue/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-8 h-8 text-primary" />
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-primary transition-colors duration-300">
                    {skill.title}
                  </h3>
                  
                  <p className="text-muted-foreground">
                    {skill.description}
                  </p>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default About;
