import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      title: "AI Threat Detection System",
      description: "Machine learning model that predicts and identifies cyber threats in real-time with 98% accuracy",
      tags: ["Python", "TensorFlow", "Security", "AI"],
      gradient: "from-neon-cyan to-neon-blue",
    },
    {
      title: "Zero Trust Architecture",
      description: "Enterprise-level security framework implementing zero trust principles across cloud infrastructure",
      tags: ["Cloud Security", "IAM", "Kubernetes", "DevSecOps"],
      gradient: "from-neon-magenta to-neon-purple",
    },
    {
      title: "Blockchain Security Audit",
      description: "Comprehensive smart contract auditing tool with automated vulnerability scanning",
      tags: ["Blockchain", "Solidity", "Web3", "Smart Contracts"],
      gradient: "from-neon-blue to-neon-cyan",
    },
    {
      title: "Neural Network Firewall",
      description: "Next-gen firewall powered by deep learning to adapt to emerging threats automatically",
      tags: ["AI", "Network Security", "Deep Learning", "Automation"],
      gradient: "from-neon-green to-neon-cyan",
    },
    {
      title: "Encrypted Communication Platform",
      description: "End-to-end encrypted messaging system with quantum-resistant cryptography",
      tags: ["Encryption", "React", "Node.js", "WebRTC"],
      gradient: "from-neon-purple to-neon-magenta",
    },
    {
      title: "Penetration Testing Toolkit",
      description: "Automated penetration testing suite with AI-powered vulnerability assessment",
      tags: ["Pentesting", "Python", "Security", "Automation"],
      gradient: "from-neon-cyan to-neon-green",
    },
  ];

  return (
    <section id="projects" className="min-h-screen py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/20 to-background" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 text-glow-magenta">
            Featured Projects
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-magenta to-neon-cyan mx-auto mb-8" />
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Innovative solutions combining cybersecurity expertise with artificial intelligence
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Card 
              key={index}
              className="group p-6 bg-card/50 backdrop-blur-sm border-primary/10 hover:border-primary/30 transition-all duration-300 cursor-pointer relative overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
              
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-3 text-foreground group-hover:text-primary transition-colors duration-300">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 text-sm">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, tagIndex) => (
                    <Badge 
                      key={tagIndex}
                      variant="outline"
                      className="border-primary/30 text-primary hover:bg-primary/10"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors">
                    <ExternalLink className="w-4 h-4" />
                    View
                  </button>
                  <button className="flex items-center gap-2 text-sm text-secondary hover:text-secondary/80 transition-colors">
                    <Github className="w-4 h-4" />
                    Code
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
