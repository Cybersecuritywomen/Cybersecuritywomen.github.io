import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";

const Skills = () => {
  const skillsData = [
    { name: "Network Security", level: 95 },
    { name: "Machine Learning", level: 90 },
    { name: "Penetration Testing", level: 92 },
    { name: "Cloud Security", level: 88 },
    { name: "Cryptography", level: 87 },
    { name: "Python", level: 93 },
    { name: "Threat Intelligence", level: 91 },
    { name: "Security Architecture", level: 89 },
  ];

  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="skills" className="min-h-screen py-20 px-4 relative" ref={sectionRef}>
      <div className="absolute inset-0 grid-pattern opacity-10" />
      
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 text-glow">
            Technical Skills
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-cyan to-neon-magenta mx-auto mb-8" />
        </div>

        <Card className="p-8 bg-card/50 backdrop-blur-sm border-primary/20">
          <div className="space-y-6">
            {skillsData.map((skill, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-foreground font-semibold">{skill.name}</span>
                  <span className="text-primary font-bold">{skill.level}%</span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden relative">
                  <div 
                    className="h-full bg-gradient-to-r from-neon-cyan via-neon-blue to-neon-magenta transition-all duration-1000 ease-out relative"
                    style={{ 
                      width: isVisible ? `${skill.level}%` : '0%',
                      boxShadow: '0 0 10px hsl(var(--neon-cyan)), 0 0 20px hsl(var(--neon-cyan) / 0.5)',
                    }}
                  >
                    <div className="absolute inset-0 animate-pulse-glow" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="mt-12 grid md:grid-cols-3 gap-6 text-center">
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-primary/20 hover:border-primary/40 transition-all duration-300">
            <div className="text-4xl font-bold text-primary mb-2">50+</div>
            <div className="text-muted-foreground">Security Audits</div>
          </Card>
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-secondary/20 hover:border-secondary/40 transition-all duration-300">
            <div className="text-4xl font-bold text-secondary mb-2">15+</div>
            <div className="text-muted-foreground">AI Models Deployed</div>
          </Card>
          <Card className="p-6 bg-card/50 backdrop-blur-sm border-accent/20 hover:border-accent/40 transition-all duration-300">
            <div className="text-4xl font-bold text-accent mb-2">99.9%</div>
            <div className="text-muted-foreground">Threat Prevention</div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Skills;
